KrowiAF = {
    Data = {};
    Categories = {};
    AchievementFunctions = {};
};