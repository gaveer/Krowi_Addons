-- [[ Namespaces ]] --
local _, addon = ...;
addon.GUI = {};
local gui = addon.GUI;