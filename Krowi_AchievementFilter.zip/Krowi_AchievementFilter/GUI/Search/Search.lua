-- [[ Namespaces ]] --
local _, addon = ...;
local gui = addon.GUI;
gui.Search = {};