local _, addon = ...; -- Global addon namespace
addon.Libs = {}; -- Global library names table
local libs = addon.Libs; -- Local library names table

libs.AceLocale = "AceLocale-3.0";