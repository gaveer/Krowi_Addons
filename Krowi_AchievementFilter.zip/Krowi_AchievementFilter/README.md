<a href="https://www.curseforge.com/wow/addons/krowi-achievement-filter" alt="Curseforge">
  <img src="https://img.shields.io/badge/curseforge-Krowi's%20Achievement%20Filter-orange" />
</a>